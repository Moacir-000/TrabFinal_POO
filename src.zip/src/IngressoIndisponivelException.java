public class IngressoIndisponivelException extends Exception{
    public IngressoIndisponivelException(String men){
        super(men);
    }
}
