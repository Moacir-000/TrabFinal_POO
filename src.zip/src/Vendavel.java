public interface Vendavel {
    public abstract double calcularPreco();
}
